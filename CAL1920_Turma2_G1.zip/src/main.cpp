#include <iostream>
#include <chrono>

#include "Menu.h"

int main() {

    menu();
    return 0;
}

